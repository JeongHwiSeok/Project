#pragma once
#include <iostream>
using namespace std;

template <typename T>

class SingleLinkedList
{
private:
	typedef struct NODE
	{
		T data;
		struct NODE* next;
	};

	NODE* head;
	NODE* tail;
	int size;

public:
	SingleLinkedList()
	{
		head = nullptr;
		tail = nullptr;
		size = 0;
	}
	void Show()
	{
		NODE* currentPtr = head;
		while (currentPtr != nullptr)
		{
			cout << currentPtr->data << endl;
			currentPtr = currentPtr->next;
		}
	}
	void PushFront(T data)
	{
		NODE* newnode = new NODE;
		newnode->data = data;
		if (head == nullptr && tail == nullptr)
		{
			newnode->next = nullptr;

			head = newnode;

			tail = newnode;
		}
		else
		{
			newnode->next = head;

			head = newnode;
		}
		size++;
	}
	void PushBack(T data)
	{
		NODE* newnode = new NODE;
		newnode->data = data;
		if (head == nullptr && tail == nullptr)
		{
			newnode->next = nullptr;

			head = newnode;

			tail = newnode;
		}
		else
		{
			tail->next = newnode;

			tail = newnode;
			tail->next = nullptr;
		}
		size++;
	}
	void PopFront()
	{
		if (head == nullptr && tail == nullptr)
		{
			cout << "Node�� ����ֽ��ϴ�" << endl;
			return;
		}
		else if (head == tail)
		{
			NODE* deletenode = head;
			head = nullptr;
			tail = nullptr;
			delete deletenode;
		}
		else
		{
			NODE* deletenode = head;
			head = deletenode->next;
			delete deletenode;
		}
		size--;
	}
	void PopBack()
	{
		if (head == nullptr && tail == nullptr)
		{
			cout << "Node�� ����ֽ��ϴ�" << endl;
			return;
		}
		else if (head == tail)
		{
			NODE* deletenode = head;
			head = nullptr;
			tail = nullptr;
			delete deletenode;
		}
		else
		{
			NODE* deletenode = head;
			int k = size;
			while (deletenode != nullptr && k > 2)
			{
				deletenode = deletenode->next;
				k--;
			}
			tail = deletenode;
			deletenode = tail->next;
			tail->next = nullptr;
			delete deletenode;
		}
		size--;
	}

	/*void DeleteNode()
	{
		NODE* deleteNode = head->next;
		head->next = deleteNode->next;
		delete deleteNode;
	}*/

	int Size()
	{
		return size;
	}
	
	~SingleLinkedList()
	{
		while (size != 0)
		{
			PopFront();
		}
	}
};

