﻿#include "CircularLinkedList.h"

int main()
{
    CircularLinkedList<int> list;
    
    list.PushBack(4);
    list.PushBack(5);
    list.PushBack(6);
    list.PushFront(100);
    list.PushFront(200);
    list.Display();
    cout << endl;

    list.PopFront();
    list.Display();
    cout << endl;

    list.PopFront();
    list.Display();
    cout << endl;

    list.PopBack();
    list.Display();
    cout << endl;
}