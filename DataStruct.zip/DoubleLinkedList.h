#pragma once
#include <iostream>
using namespace std;

template <typename T>

class DoubleLinkedList
{
private:
	typedef struct NODE
	{
		T data;
		struct NODE* prev;
		struct NODE* next;
	};

	NODE* head;
	NODE* tail;
	int size;

public:
	DoubleLinkedList()
	{
		head = nullptr;
		tail = nullptr;
		size = 0;
	}
	void PushFront(T data)
	{
		NODE* newnode = new NODE;
		newnode->data = data;
		newnode->next = nullptr;
		newnode->prev = nullptr;
		if (head == nullptr && tail == nullptr)
		{
			head = newnode;

			tail = newnode;
		}
		else
		{
			newnode->next = head;
			head->prev = newnode;

			head = newnode;
			head->prev = nullptr;
		}
		size++;
	}
	void PushBack(T data)
	{
		NODE* newnode = new NODE;
		newnode->data = data;
		newnode->next = nullptr;
		newnode->prev = nullptr;
		if (head == nullptr && tail == nullptr)
		{
			head = newnode;

			tail = newnode;
		}
		else
		{
			tail->next = newnode;
			newnode->prev = tail;

			tail = newnode;
			tail->next = nullptr;
		}
		size++;
	}

	void Insert(int k, T data)
	{
		if( k <= 1 )
		{
			PushFront(data);
			return;
		}
		NODE* mfnode = head;
		NODE* mbnode = head;
		NODE* newnode = new NODE;
		newnode->data = data;
		newnode->next = nullptr;
		newnode->prev = nullptr;

		while (k > 1)
		{
			mfnode = mbnode;
			mbnode = mbnode->next;
			k--;
		}

		newnode->next = mbnode;
		newnode->prev = mfnode;
		mbnode->prev = newnode;
		mfnode->next = newnode;
		size++;
	}

	void PopFront()
	{
		if (head == nullptr && tail == nullptr)
		{
			cout << "Node�� ����ֽ��ϴ�" << endl;
			return;
		}
		else if (head == tail)
		{
			NODE* deletenode = head;
			head = nullptr;
			tail = nullptr;
			delete deletenode;
		}
		else
		{
			NODE* deletenode = head;
			head = deletenode->next;
			head->prev = nullptr;
			delete deletenode;
		}
		size--;
	}

	void PopBack()
	{
		if (head == nullptr && tail == nullptr)
		{
			cout << "Node�� ����ֽ��ϴ�" << endl;
			return;
		}
		else if (head == tail)
		{
			NODE* deletenode = tail;
			head = nullptr;
			tail = nullptr;
			delete deletenode;
		}
		else
		{
			NODE* deletenode = tail;
			tail = deletenode->prev;
			tail->next = nullptr;
			delete deletenode;
		}
		size--;
	}

	void FrontShow()
	{
		NODE* currentPtr = head;
		while (currentPtr != nullptr)
		{
			cout << currentPtr->data << endl;
			currentPtr = currentPtr->next;
		}
	}

	void BackShow()
	{
		NODE* currentPtr = tail;
		while (currentPtr != nullptr)
		{
			cout << currentPtr->data << endl;
			currentPtr = currentPtr->prev;
		}
	}

	int Size()
	{
		return size;
	}

	~DoubleLinkedList()
	{
		while (size != 0)
		{
			PopFront();
		}
	}
};

