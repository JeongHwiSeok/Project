#pragma once
#include <iostream>
using namespace std;

template <typename T>

class CircularLinkedList
{
private:
	typedef struct NODE
	{
		T data;
		struct NODE* next;
	};

	NODE* head;
	int size;

public:
	CircularLinkedList()
	{
		head = nullptr;
		size = 0;
	}

	void PushFront(T data)
	{
		NODE* newnode = new NODE;
		newnode->data = data;

		if (head == nullptr)
		{
			newnode->next = newnode;
			head = newnode;
		}
		else
		{
			newnode->next = head->next;
			head->next = newnode;
			head = newnode;
		}
		size++;
	}

	void PushBack(T data)
	{
		NODE* newnode = new NODE;
		newnode->data = data;

		if (head == nullptr)
		{
			newnode->next = newnode;
			head = newnode;
		}
		else
		{
			newnode->next = head->next;
			head->next = newnode;
		}
		size++;
	}

	void PopBack()
	{
		if (head == nullptr)
		{
			cout << "Node�� ����ֽ��ϴ�" << endl;
			return;
		}
		else if (size == 1)
		{
			NODE* deletenode = head;
			head = nullptr;
			delete deletenode;
		}
		else
		{
			NODE* deletenode = head;
			int count = size;
			NODE* currentnode = head;
			while (count > 1)
			{
				currentnode = currentnode->next;
				count--;
			}
			currentnode->next = deletenode->next;
			head = currentnode;
			delete deletenode;
		}
		size--;
	}

	void PopFront()
	{
		if (head == nullptr)
		{
			cout << "Node�� ����ֽ��ϴ�" << endl;
			return;
		}
		else if (size == 1)
		{
			NODE* deletenode = head;
			head = nullptr;
			delete deletenode;
		}
		else
		{
			NODE* deletenode = head->next;
			head->next = deletenode->next;
			delete deletenode;
		}
		size--;
	}

	int Size()
	{
		return size;
	}

	void Display()
	{
		NODE* currentPtr = head;
		int count = size;
		while (count != 0)
		{
			cout << currentPtr->data << endl;
			currentPtr = currentPtr->next;
			count--;
		}
	}

	~CircularLinkedList()
	{
		while (size != 0)
		{
			PopFront();
		}
	}
};