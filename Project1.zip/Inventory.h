#pragma once
#include "Item.h"
#include "InputKey.h"
#include <iostream>
using namespace std;

class Inventory
{
private:
	Item* items;
	int size = 0;
	int lineX;
	int lineY;
	int selectIndex;
	int truecount = 0;

	int resultX = 0;
	int resultY = 0;

public:
	Inventory(int x, int y);
	void SelectNumber(InputKey inputkey);
	void SelectItemInfo();
	void Renderer();
	void Additem(int x, int y, int z);
};

