#pragma once
#include <iostream>
#include "Mouse.h"
#include "Computer.h"
#include "Bank.h"
using namespace std;

int main()
{
#pragma region 다중 상속
	// 하나의 하위 클래스가 여러 개의 상위 클래스를 상속받는 것
	// C#, Java는 다중 상속이 되지 않음

	/*Computer computer;
	computer.Use();*/

#pragma endregion

#pragma region Friend
	// Friend로 선언된 클래스의 private 및 protected 멤버에 접근할 수 있도록 설정해주는 기능

	Bank bank;
	Player player;
	player.ShowInfo();
	bank.Withdrawal(player, 15000);
	bank.ShowInfo();
	player.ShowInfo();

#pragma endregion


	return 0;
}