#pragma once
#include "Player.h"
#include <iostream>
using namespace std;

#pragma region class의 전방선언
	// 불필요한 헤더 파일이 복잡하게 포함되는 것를 방지하며, 결과적으로는 컴파일 속도를 향상시킴
#pragma endregion


class Player;

class Bank
{
private:
	int bankMoney = 0;

public:
	void Withdrawal(Player& player, int money);
	void ShowInfo();
};

