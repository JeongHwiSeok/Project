#pragma once
#include "Mouse.h"
#include "Keyboard.h"
#include <iostream>
using namespace std;

class Computer : public Mouse, public Keyboard
{
public:
	Computer();

	void Use();
};

