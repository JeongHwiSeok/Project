﻿#include "InputKey.h"
InputKey::InputKey()
{
	x = 0;
    y = 0;
	key = 0;
}

void InputKey::Move(int upperX, int upperY)
{
    GotoXY(x, y);

    if (_kbhit()) // 키보드 입력을 확인하는 함수
    {
        key = _getch();

        if (key == -32)
        {
            key = _getch();
        }

        switch (key)
        {
        case UP:
            if (y > 1)
            {
                y--;
            }
            break;

        case LEFT:
            if (x > 0)
            {
                x -= 2;
            }
            break;

        case RIGHT:
            if (x < (upperX-1)*2)
            {
                x += 2;
            }
            break;

        case DOWN:
            if (y < upperY)
            {
                y++;
            }
            break;
        }
    }
    system("cls");
}
void InputKey::Input(Rhythm rhythm)
{

    if (_kbhit()) // 키보드 입력을 확인하는 함수
    {
        key = _getch();

        if (key == -32)
        {
            key = _getch();
        }

        switch (key)
        {
        case UP:
            if (rhythm.vector[rhythm.vector.size() - 1] == "↑")
            {
                rhythm.vector.pop_back();
            }
            else
            {
                rhythm.Lifeset(1);
            }
            break;

        case LEFT:
            if (rhythm.vector[rhythm.vector.size() - 1] == "←")
            {
                rhythm.vector.pop_back();
            }
            else
            {
                rhythm.Lifeset(1);
            }
            break;

        case RIGHT:
            if (rhythm.vector[rhythm.vector.size() - 1] == "→")
            {
                rhythm.vector.pop_back();
            }
            else
            {
                rhythm.Lifeset(1);
            }
            break;

        case DOWN:
            if (rhythm.vector[rhythm.vector.size() - 1] == "↓")
            {
                rhythm.vector.pop_back();
            }
            else
            {
                rhythm.Lifeset(1);
            }
            break;
        }
    }
    system("cls");
}

int InputKey::GetX()
{
    return x;
}

int InputKey::GetY()
{
    return y;
}

void InputKey::GotoXY(int x, int y)
{
	// x, y 좌표 설정
	COORD position = { x, y };

	// 커서 이동
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), position);
}
