#pragma once
#include "Component.h"
#include <iostream>
using namespace std;

class Mouse : virtual public Component
{
public:
	Mouse();

	void Input();
	void OnDrag();
};

