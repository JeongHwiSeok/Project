#pragma once
#include <iostream>
using namespace std;

class Item
{
private:
	const char* name;
	int price;
	bool check;

public:
	Item(int price = 0, const char* name = "");

	void SetCheck(bool check);
	bool GetCheck();

	void SetItemInfo(int price, const char*name);
	void Information();
};

