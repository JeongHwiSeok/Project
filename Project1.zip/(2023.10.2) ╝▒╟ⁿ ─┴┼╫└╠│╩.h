#pragma once
#include <iostream>
#include "InputKey.h"
#include "Rhythm.h"
#include <vector>
#include <deque>
using namespace std;

#pragma region 선형 컨테이너
// 데이터를 선형으로 저장하며, 특별한 제약이나 규칙이 없는 일반적인 컨테이너


#pragma endregion

void GotoXY(int x, int y)
{
	// x, y 좌표 설정
	COORD position = { x, y };

	// 커서 이동
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), position);
}

int main()
{
#pragma region Vector 컨테이너

	//vector<int> vector;

	//// push_back() : 뒤 쪽에 데이터를 저장하는 함수
	////  0	 1	  2  
	//// [10] [20] [30]
	//vector.push_back(10);
	//vector.push_back(20);
	//vector.push_back(30);

	//cout << "vector.size : " << vector.size() << endl;
	//cout << "capacity : " << vector.capacity() << endl;

	//for (int i = 0; i < vector.size(); i++)
	//{
	//	cout << vector[i] << endl;
	//}

	//vector.push_back(40);
	//vector.push_back(50);

	//cout << "vector.size : " << vector.size() << endl;
	//cout << "capacity : " << vector.capacity() << endl;

	//vector.pop_back();

	//cout << "vector.size : " << vector.size() << endl;
	//cout << "capacity : " << vector.capacity() << endl;

	//for (int i = 0; i < vector.size(); i++)
	//{
	//	cout << vector[i] << endl;
	//}

#pragma endregion

#pragma region 리듬 게임

	// life, score를 포함
	// 랜덤함수를 이용한 방향키 랜덤 생성
	// 임의의 방향키가 주어진 상황에서 뒤에서부터 입력받아 일치된 경우 score를 올리고 주어진 방향키 제거
	// 일치하지 않은 경우 life감소

	/*Rhythm rhythm;
	InputKey inputkey;

	for (int i = 0 ; i < 40 ; i++)
	{
		cout << "*";
	}
	cout << endl;

	while (rhythm.Getlife() > 0)
	{
		int level = 5;
		rhythm.Renderer(level);
		inputkey.Input(rhythm);
	}*/


#pragma endregion

#pragma region Deque 컨테이너
	// Deque 선언
	/*deque<int> deque;

	deque.push_back(10);
	deque.push_back(20);
	deque.push_front(99);

	for (int i = 0; i < deque.size(); i++)
	{
		cout << deque[i] << endl;
	}*/

#pragma endregion



	return 0;
}