#pragma once
#include <iostream>
#include "Inventory.h"
#include "Item.h"
#include "InputKey.h"
using namespace std;

void GotoXY(int x, int y)
{
	// x, y 좌표 설정
	COORD position = { x, y };

	// 커서 이동
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), position);
}

int main()
{
	int x;
	int y;
	//int z;
	//int count = 0;
	cin >> x;
	cin >> y;
	InputKey inputkey;
	Inventory inventory(x, y);
	while (true)
	{
		GotoXY(0, 0);
		inventory.Renderer();
		inventory.Additem(x, y, 1);
		inputkey.Move(x, y);
		inventory.SelectNumber(inputkey);
		GotoXY(0, y + 1);
		inventory.SelectItemInfo();

		/*cout << "인벤토리에 넣을 아이템의 갯수를 입력하십시오." << endl;
		cin >> z;
		count += z;
		inventory.Additem(x,y,count);
		if (count > x * y)
		{
			break;
		}*/
	}

	return 0;
}
// Additem(); 함수 추가