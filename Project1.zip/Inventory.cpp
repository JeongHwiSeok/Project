﻿#include "Inventory.h"
#include "InputKey.h"

Inventory::Inventory(int x, int y)
{
	selectIndex = 0;
	lineX = x;
	lineY = y;

	size = x * y;
	items = new Item[size];

	for (int i = 0; i < size; i++)
	{
		items[i].SetCheck(false);
	}
}

void Inventory::Renderer()
{
	for (int i = 0; i < size; i++)
	{
		if (i % lineX == 0)
		{
			cout << endl;
		}
		if (items[i].GetCheck() == false)
		{
			cout << "□";
		}
		else if (items[i].GetCheck() == true)
		{
			cout << "■";
		}
	}
	cout << endl;
}

void Inventory::Additem(int x, int y, int z)
{
	size = x * y;
	/*if (z <= size)
	{
		for (int i = truecount; i < z; i++)
		{
			if (items[1].GetCheck() == false)
			{
				items[1].SetCheck(true);
			}
		}
	}
	else
	{
		for (int i = truecount; i < size; i++)
		{
			if (items[i].GetCheck() == false)
			{
				items[i].SetCheck(true);
			}
		}
		cout << "아이템이 더 이상 들어가지 않습니다." << endl;
	}
	truecount = z;*/
	items[0].SetItemInfo(200, "무기");
	items[0].SetCheck(true);
	items[1].SetItemInfo(500, "포션");
	items[1].SetCheck(true);
}

void Inventory::SelectNumber(InputKey inputkey)
{
	resultX = inputkey.GetX() / 2;
	resultY = (inputkey.GetY() - 1) * lineX;
	cout << resultX + resultY << endl;
}

void Inventory::SelectItemInfo()
{
	if (items[resultX + resultY].GetCheck() == true)
	{
		items[resultX + resultY].Information();
	}
	else
	{
		cout << "비어있습니다";
	}
}
