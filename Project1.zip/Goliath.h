#pragma once
#include "Mechanic.h"

class Goliath : public Mechanic
{
public:
	Goliath();

#pragma region �Լ��� �������̵�
	
	
	virtual void Genesis();

	virtual void Move();

	virtual void Attack();

	~Goliath();
#pragma endregion

};