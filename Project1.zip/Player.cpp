#include "Player.h"

void Player::ShowInfo()
{
	cout << "Player Money : " << money << endl;
}

int Player::GetMoney()
{
	return money;
}
