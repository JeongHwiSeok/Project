﻿#include "Rhythm.h"

Rhythm::Rhythm()
{
	life = 5;
	score = 0;
    key = 0;
    vector = {};
}

void Rhythm::Lifeset(int x)
{
    life -= x;
}

void Rhythm::Scoreset()
{
}

void Rhythm::Renderer(int level)
{
    srand(time(NULL));
	for (int i = 0; i < level; i++)
	{
		key = rand()%4;
        switch (key)
        {
            case 0:
                vector.push_back("↑");
                break;

            case 1:
                vector.push_back("←");
                break;

            case 2:
                vector.push_back("→");
                break;

            case 3:
                vector.push_back("↓");
                break;
        }
    }

    for (int i = 0; i < vector.size(); i++)
    {
        cout << vector[i] << " ";
    }
    //system("cls");
}

int Rhythm::Getlife()
{
    return life;
}

int Rhythm::Getscore()
{
    return score;
}