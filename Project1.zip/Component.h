#pragma once
#include <iostream>
using namespace std;

class Component
{
public:
	Component();
};

