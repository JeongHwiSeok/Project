#include "Mouse.h"

Mouse::Mouse()
{
	cout << "Create Mouse" << endl;
}

void Mouse::Input()
{
	cout << "Input Mouse" << endl;
}

void Mouse::OnDrag()
{
	cout << "Mouse Drag" << endl;
}
