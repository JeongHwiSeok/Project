#pragma once
#include "Unit.h"

class Firebet : public Unit
{
public:
	void Skill() override;
	void Damage(int value) override;
	int GetHP() override;
	int MaxHP() override;
};

