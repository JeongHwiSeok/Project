#pragma once
#include <iostream>
#include <string>
#include <list>
#include <vector>
using namespace std;

int main()
{
#pragma region 연관 컨테이너
	// KEY와 VALUE가 하나의 구성으로 이루어진 컨테이너

	/*string content = "content";

	cout << content << endl;
	cout << content.size() << endl;*/

#pragma endregion

#pragma region 리스트

	//list<int> dataList;

	//dataList.push_back(10);
	//dataList.push_front(50);
	//dataList.push_front(25);
	//dataList.push_back(33);
	//// begin                end
	//// [25] [50] [10] [33]
	//dataList.begin(); // 첫번째 주소를 반환
	//dataList.end();	  // 마지막에 있는 그 다음 주소를 반환
	//list<int>::iterator iter;

	//iter = dataList.begin();
	//
	//iter++;
	//
	//dataList.insert(iter, 77);
	//
	//for (iter = dataList.begin(); iter != dataList.end(); iter++)
	//{
	//	cout << *iter << endl;
	//}

	//vector<int> vectorInt;

	//vector<int>::iterator vectorIter;

	//vectorInt.reserve(8);

	//vectorInt.emplace_back(10);
	//vectorInt.emplace_back(20);
	//vectorInt.emplace_back(30);
	//vectorInt.emplace_back(40);

	//vectorIter = vectorInt.begin();

	//vectorInt.erase(vectorIter + 2);

	//for (int i = 0; i < vectorInt.size(); i++)
	//{
	//	cout << vectorInt[i] << endl;
	//}

	//while (list.empty()==false)
	//{
	//	//cout << list.front() << endl;
	//	//cout << list.back() << endl;
	//	//list.pop_front();
	//}

#pragma endregion


	return 0;
}