#include "Component.h"

Component::Component()
{
	cout << "Create Component" << endl;
}
