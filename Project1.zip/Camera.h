#pragma once
#include <iostream>
using namespace std;

class Camera
{
private:
	float view;
public:
	Camera();
	~Camera();

	Camera::Information() const;
	
};