#pragma once
#include <iostream>
#include <cstdlib>
#include <time.h>
#include <conio.h>
#include <Windows.h>
#include <vector>

using namespace std;

#define UP 72
#define DOWN 80
#define LEFT 75
#define RIGHT 77

class Rhythm
{
private:
	int life;
	int score;
	int key;
	

public:
	vector<const char*> vector;
	Rhythm();
	void Lifeset(int x);
	void Scoreset();
	void Renderer(int level);
	
	int Getlife();
	int Getscore();
};

