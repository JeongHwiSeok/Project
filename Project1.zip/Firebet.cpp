#include "Firebet.h"
using namespace std;

void Firebet::Skill()
{
	cout << "������" << endl;
}

void Firebet::Damage(int value)
{
	health -= value;
}

int Firebet::MaxHP()
{
	health = 50;
	return health;
}

int Firebet::GetHP()
{
	return health;
}