#pragma once
#include <iostream>
using namespace std;

#pragma region final
	// 하위 클래스에서 더 이상 재정의 할 수 없도록 선언하는 기능

	class Hero
	{
		virtual void BasicSkill() {};
		virtual void MagicSkill() {};
	};

	class Crusaders : public Hero
	{
		virtual void BasicSkill() {};
		virtual void MagicSkill() final {};
	};

	class Fighter : public Crusaders
	{
		virtual void BasicSkill() {};
		// virtual void MagicSkill() {}; Error
	};

#pragma endregion


int main()
{
	
	return 0;
}