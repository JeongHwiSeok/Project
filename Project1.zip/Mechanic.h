#pragma once
#include <iostream>
using namespace std;

class Mechanic
{
protected:
	int health;
	int attack;

public:
	Mechanic();

	virtual void Genesis();

	virtual void Move();
	
	virtual void Attack();

	virtual ~Mechanic();
};