#include "Marine.h"
using namespace std;

void Marine::Skill()
{
	cout << "������" << endl;
}

void Marine::Damage(int value)
{
	health -= value;
}

int Marine::MaxHP()
{
	health = 40;
	return health;
}

int Marine::GetHP()
{
	return health;
}