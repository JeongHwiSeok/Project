#pragma once
#include <iostream>
#include "Rhythm.h"
#include <conio.h>
#include <Windows.h>

#define UP 72
#define DOWN 80
#define LEFT 75
#define RIGHT 77

using namespace std;

class InputKey
{
private:
	int x = 0;
	int y = 1;
	char key = 0;

public:
	int GetX();
	int GetY();

	InputKey();
	void Move(int upperX, int upperY);
	void Input(Rhythm rhythm);
	void GotoXY(int x, int y);
};

