#include "Keyboard.h"

Keyboard::Keyboard()
{
	cout << "Create Keyboard" << endl;
}

void Keyboard::Input()
{
	cout << "Input Keyboard" << endl;
}

void Keyboard::OnButton()
{
	cout << "Select Key" << endl;
}
