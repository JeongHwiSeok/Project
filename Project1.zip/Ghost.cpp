#include "Ghost.h"
using namespace std;

void Ghost::Skill()
{
	cout << "������" << endl;
}

void Ghost::Damage(int value)
{
	health -= value;
}

int Ghost::MaxHP()
{
	health = 45;
	return health;
}

int Ghost::GetHP()
{
	return health;
}