#pragma once
#include "Component.h"
#include <iostream>
using namespace std;

class Keyboard : virtual public Component
{
public:
	Keyboard();

	void Input();
	void OnButton();
};

